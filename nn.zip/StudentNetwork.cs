﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace NeuralNetwork1
{
    public class StudentNetwork : BaseNetwork
    {
        public double learning_rate = 0.15; 

        // Массивы данных
        private double[][] layers;      
        private double[][] errors;      
        private double[][,] weights; 

        private Random rand = new Random();
        private Stopwatch watch = new Stopwatch();

        // Классическая Сигмоида
        private double Sigmoid(double x) => 1.0 / (1.0 + Math.Exp(-x));

        // Производная Сигмоиды: y * (1 - y)
        private double SigmoidDerivative(double y) => y * (1.0 - y);

        public StudentNetwork(int[] structure)
        {
            // Инициализация массивов
            layers = new double[structure.Length][];
            errors = new double[structure.Length][];
            weights = new double[structure.Length - 1][,];

            for (int i = 0; i < structure.Length; i++)
            {
                layers[i] = new double[structure[i] + 1];
                errors[i] = new double[structure[i] + 1];

                layers[i][structure[i]] = 1.0;
            }

            // Инициализация весов
            for (int k = 0; k < structure.Length - 1; k++)
            {
                int inputs = layers[k].Length;     
                int outputs = structure[k + 1];    

                weights[k] = new double[inputs, outputs];

                for (int i = 0; i < inputs; i++)
                {
                    for (int j = 0; j < outputs; j++)
                    {
                        weights[k][i, j] = (rand.NextDouble() - 0.5) * (2.0 / Math.Sqrt(inputs));
                    }
                }
            }
        }


        private void ForwardPass()
        {
            for (int k = 0; k < weights.Length; k++) 
            {
                int inputs = layers[k].Length;
                int outputs = layers[k + 1].Length - 1; 

                Parallel.For(0, outputs, j =>
                {
                    double sum = 0;
                    for (int i = 0; i < inputs; i++)
                    {
                        sum += layers[k][i] * weights[k][i, j];
                    }
                    layers[k + 1][j] = Sigmoid(sum);
                });

            }
        }

        //Обратный проход 
        private void BackPropagation(double[] expectedOutput)
        {
            int lastLayer = layers.Length - 1;
            int outputCount = layers[lastLayer].Length - 1; 

            Parallel.For(0, outputCount, j =>
            {
                double output = layers[lastLayer][j];
                double error = expectedOutput[j] - output;
                errors[lastLayer][j] = error * SigmoidDerivative(output);
            });

            // Ошибка скрытых слоев
            for (int k = lastLayer - 1; k >= 0; k--)
            {
                int currentLayerSize = layers[k].Length;     
                int nextLayerSize = layers[k + 1].Length - 1; 

                Parallel.For(0, currentLayerSize, i =>
                {
                    double sum = 0;
                    for (int j = 0; j < nextLayerSize; j++)
                    {
                        // Суммируем ошибки, пришедшие назад по весам
                        sum += errors[k + 1][j] * weights[k][i, j];
                    }
                    // Умножаем на производную текущего нейрона
                    errors[k][i] = sum * SigmoidDerivative(layers[k][i]);
                });
            }

            //Обновление весов
            for (int k = 0; k < weights.Length; k++)
            {
                int inputs = layers[k].Length;
                int outputs = layers[k + 1].Length - 1;

                Parallel.For(0, outputs, j =>
                {
                    for (int i = 0; i < inputs; i++)
                    {
                        // Gradient = Error * Input
                        double gradient = errors[k + 1][j] * layers[k][i];
                        weights[k][i, j] += learning_rate * gradient;
                        // Используем += так как ошибка была (Target - Output)
                    }
                });
            }
        }

        // Обучение на датасете
        public override double TrainOnDataSet(SamplesSet samplesSet, int epochsCount, double acceptableError, bool parallel)
        {
            watch.Restart();

            // Копируем список для перемешивания
            var samples = samplesSet.samples.ToList();
            double totalError = 0;

            for (int epoch = 0; epoch < epochsCount; epoch++)
            {
                int n = samples.Count;
                while (n > 1)
                {
                    n--;
                    int k = rand.Next(n + 1);
                    var value = samples[k];
                    samples[k] = samples[n];
                    samples[n] = value;
                }

                totalError = 0;

                foreach (var sample in samples)
                {
                    for (int i = 0; i < sample.input.Length; i++)
                        layers[0][i] = sample.input[i];

                    ForwardPass();

                    double sampleError = 0;
                    var lastLayer = layers[layers.Length - 1];
                    for (int i = 0; i < sample.outputVector.Length; i++)
                    {
                        sampleError += Math.Pow(sample.outputVector[i] - lastLayer[i], 2);
                    }
                    totalError += sampleError;

                    BackPropagation(sample.outputVector);
                }

                totalError /= samples.Count;

                OnTrainProgress((double)(epoch + 1) / epochsCount, totalError, watch.Elapsed);

                if (totalError < acceptableError) break;
            }

            watch.Stop();
            return totalError;
        }

        public override int Train(Sample sample, double acceptableError, bool parallel)
        {
            int i = 0;
            while (i < 500)
            {
                i++;
                for (int j = 0; j < sample.input.Length; j++) layers[0][j] = sample.input[j];
                ForwardPass();

                // Проверка ошибки
                double error = 0;
                var lastLayer = layers[layers.Length - 1];
                for (int k = 0; k < sample.outputVector.Length; k++)
                    error += Math.Pow(sample.outputVector[k] - lastLayer[k], 2);

                if (error < acceptableError) break;

                BackPropagation(sample.outputVector);
            }
            return i;
        }

        protected override double[] Compute(double[] input)
        {
            // Копируем вход
            for (int i = 0; i < input.Length; i++)
                layers[0][i] = input[i];

            ForwardPass();

            int outputCount = layers[layers.Length - 1].Length - 1;
            double[] result = new double[outputCount];
            Array.Copy(layers[layers.Length - 1], result, outputCount);

            return result;
        }
    }
}
